package com.example.oh_dear;

import android.app.NotificationManager;
import android.content.Context;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class MainActivity extends AppCompatActivity {
    private TextView data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        setContentView(R.layout.notification);
        data = (TextView) findViewById(R.id.textView);
        runUdpServer();
    }

    private void runUdpServer() {
        final NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setSmallIcon(R.drawable.ic_launcher_background);
        mBuilder.setContentTitle("Notification Alert, Click Me!");
        mBuilder.setContentText("Hi, This is Android Notification Detail!");
        final NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        new Thread(new Runnable() {
            public void run() {
                Log.i("Entering run1", "Enter");
                try {
                    int port = 10000;
                    int counter = 0;
                    Log.i("Entering run2", "Enter");
                    DatagramSocket dsocket = new DatagramSocket(port);
                    byte[] buffer = new byte[2048];
                    Log.i("Entering run3", "Enter");
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    while (true) {

                        dsocket.receive(packet);
                        counter=counter+1;
                        final String lText = new String(buffer, 0, packet.getLength());
                        Log.i("UDP packet received", lText);

                        packet.setLength(buffer.length);

                        try {
                            final int finalCounter = counter;
                            runOnUiThread(new Runnable() {

                                @Override
                                public void run() {
                                    data.setText(lText+ finalCounter);
                                    mNotificationManager.notify(0, mBuilder.build());
                                }
                            });
                            Thread.sleep(300);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                } catch (Exception e) {
                    System.err.println(e);
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
